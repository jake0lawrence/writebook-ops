ActiveSupport::Inflector.inflections(:en) do |inflect|
  inflect.irregular "leaf", "leaves"
end
