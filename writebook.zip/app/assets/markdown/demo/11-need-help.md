---
title: Need help?
---
# Help

Everyone gets stuck sometimes. Here's how to deal with some common situations.

## I need to sign in on another device

You can easily sign in on another device without even typing your password by sharing your personal link.

 ![session-transfer.png](/u/session-transfer-xa3uF7.png)

## Password recovery

Someone forgot their password and can't sign in. It happens. Administrators can access someone else's personal sign in link to help them get back in.

 ![password-recovery.png](/u/password-recovery-XKwPtX.png)
