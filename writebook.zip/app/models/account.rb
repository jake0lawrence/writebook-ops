class Account < ApplicationRecord
  include Joinable
end
